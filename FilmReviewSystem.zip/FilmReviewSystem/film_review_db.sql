-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 17, 2026 at 03:19 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `film_review_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_messages`
--

INSERT INTO `contact_messages` (`id`, `name`, `email`, `message`, `sent_at`) VALUES
(1, 'bono', 'bono@gmail.com', 'i need help', '2026-04-04 19:39:56'),
(2, 'Raj Tripathi', 'rajt5113@gmail.com', 'hi rajjjj', '2026-04-07 06:34:37'),
(3, 'Raj Tripathi', 'rajt5113@gmail.com', 'yooo wassup', '2026-04-16 13:45:52'),
(4, 'Raj Tripathi', 'rajt5113@gmail.com', 'yooooooooooooooooooooooooooooo', '2026-04-16 13:54:33'),
(5, 'Raj Tripathi', 'rajt5113@gmail.com', 'testing', '2026-04-17 11:07:26');

-- --------------------------------------------------------

--
-- Table structure for table `films`
--

CREATE TABLE `films` (
  `id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `genre` varchar(50) DEFAULT NULL,
  `release_year` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `films`
--

INSERT INTO `films` (`id`, `title`, `genre`, `release_year`, `description`, `created_at`) VALUES
(1, 'Inception', 'Sci-Fi', 2010, 'A thief who steals corporate secrets through dream-sharing technology.', '2026-03-13 15:55:23'),
(2, 'The Dark Knight', 'Action', 2008, 'Batman faces the Joker, a criminal mastermind in Gotham City.', '2026-03-13 15:55:23'),
(3, 'Interstellar', 'Sci-Fi', 2014, 'A team of explorers travel through a wormhole in space.', '2026-03-13 15:55:23'),
(4, 'shaolin soccer', 'comedy', 2001, 'football movie', '2026-03-13 16:00:19'),
(5, 'spiderman', 'comedy', 2002, 'good movie', '2026-03-19 06:14:54'),
(7, 'your name', 'Romance', 2016, 'Two teenagers a girl in a rural town and a boy in Tokyo suddenly begin to mysteriously swap bodies. As they form a deep connection by leaving notes for one another, they race to meet in person and uncover a cosmic secret that transcends space and time.', '2026-04-04 19:53:03'),
(8, 'The Lord of the rings', 'Epic Fantasy', 2001, 'The Lord of the Rings is a trilogy of epic fantasy films directed by Peter Jackson, based on J. R. R. Tolkien\'s novel of the same name.  The series follows the hobbit Frodo Baggins as he and the Fellowship of the Ring embark on a perilous quest to destroy the One Ring in the fires of Mount Doom to defeat the Dark Lord Sauron.', '2026-04-17 11:17:11');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `film_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `review_text` text NOT NULL,
  `rating` int(11) NOT NULL CHECK (`rating` between 1 and 10),
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `film_id`, `user_id`, `review_text`, `rating`, `image`, `created_at`) VALUES
(1, 2, 2, 'amazing movie', 8, '69b434380a639.webp', '2026-03-13 15:58:48'),
(2, 4, 2, 'funny hahahahhahahahahhaha', 10, '69b434c771196.jpg', '2026-03-13 16:01:11'),
(4, 5, 3, 'good', 9, '69c3a5b8e1b99.webp', '2026-03-25 09:07:04'),
(6, 7, 2, 'good movie', 7, '69e2138611467.png', '2026-04-17 10:59:05');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `role` enum('admin','user') DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `profile_picture`, `role`, `created_at`) VALUES
(1, 'admin', 'admin@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'profile_69e21dfedbb89.png', 'admin', '2026-03-13 15:55:10'),
(2, 'raj5113', 'rajt5113@gmail.com', '$2y$10$j.m1vrfPln5gpeZJXlnLU.kBbDvj0etNRUhhEZHQmbkWQISflf.xq', 'profile_69e0fc0735056.webp', 'user', '2026-03-13 15:57:01'),
(3, 'bono', 'bono@gmail.com', '$2y$10$4JE43z.yoZtkUXJkhBJR5uDt/kam59GWAcD5V/yeGsq4uD5H6AqR.', NULL, 'user', '2026-03-25 06:22:12'),
(4, 'rajat', 'rajat5113@gmail.com', '$2y$10$fAMsmkVZcXi9PL2DLxlvdu5BFqszLLNC1E1F0y7lo6CYzduf2tJNK', NULL, 'user', '2026-04-16 13:28:57'),
(5, 'user1', 'user1@gmail.com', '$2y$10$g5KCzK7XOcGrt0thUbwMsuFy4iu5g.kArYAuwv/0aJ1hpMJC44cJ6', NULL, 'user', '2026-04-17 10:31:46'),
(6, 'maru', 'maru55@email.com', '$2y$10$3u6OYqzG7Z0olYMt.hYl5ujWixZp6/VuLxWJbBXizN0/eFc8HuHDq', NULL, 'user', '2026-04-17 11:34:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `films`
--
ALTER TABLE `films`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `film_id` (`film_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `films`
--
ALTER TABLE `films`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`film_id`) REFERENCES `films` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
