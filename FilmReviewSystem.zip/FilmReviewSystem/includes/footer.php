<?php
// includes/footer.php
// Included at the bottom of every page
?>

</div><!-- end .container -->

<footer class="footer bg-black text-white py-5 mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-4">
                <h5 class="fw-bold mb-3" style="color: var(--primary-color);">FilmReviews</h5>
                <p class="text-muted small">Your ultimate source for film reviews, ratings, and insights. Join our community of movie lovers today.</p>
            </div>
            <div class="col-md-2 mb-4">
                <h6 class="fw-bold mb-3 text-white">Quick Links</h6>
                <ul class="list-unstyled">
                    <li><a href="index.php" class="footer-link small">Home</a></li>
                    <li><a href="contact.php" class="footer-link small">Contact</a></li>
                </ul>
            </div>
            <div class="col-md-2 mb-4">
                <h6 class="fw-bold mb-3 text-white">Community</h6>
                <ul class="list-unstyled">
                    <li><a href="register.php" class="footer-link small">Register</a></li>
                    <li><a href="login.php" class="footer-link small">Login</a></li>
                </ul>
            </div>
            <div class="col-md-4 mb-4">
                <h6 class="fw-bold mb-3 text-white">Connect With Us</h6>
                <div class="d-flex gap-3">
                    <a href="#" class="footer-link small">Twitter</a>
                    <a href="#" class="footer-link small">Instagram</a>
                    <a href="#" class="footer-link small">Facebook</a>
                </div>
            </div>
        </div>
        <hr class="my-4 border-secondary" style="opacity: 0.2;">
        <div class="text-center">
            <p class="mb-0 text-muted small">&copy; <?php echo date('Y'); ?> Film Review System | Designed for Movie Lovers</p>
        </div>
    </div>
</footer>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
