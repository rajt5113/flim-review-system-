<?php
// profile.php
// Allows users to view and edit their profile (username, email, profile picture)

require_once 'DatabaseConnection.php';
require_once 'includes/header.php';

// Must be logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$error   = '';
$success = '';

// Fetch current user data
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    header('Location: logout.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email    = trim($_POST['email']);
    $new_image_name = $user['profile_picture'];

    // Validation
    if (empty($username) || empty($email)) {
        $error = 'Username and email are required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        // Check if username or email is already taken by someone else
        $stmt = $pdo->prepare("SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?");
        $stmt->execute([$username, $email, $user_id]);

        if ($stmt->rowCount() > 0) {
            $error = 'Username or email already taken by another user.';
        } else {
            // Handle profile picture upload
            if (!empty($_FILES['profile_picture']['name'])) {
                $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                $ext     = strtolower(pathinfo($_FILES['profile_picture']['name'], PATHINFO_EXTENSION));

                if (!in_array($ext, $allowed)) {
                    $error = 'Only JPG, PNG, GIF or WEBP images are allowed.';
                } elseif ($_FILES['profile_picture']['size'] > 2000000) { // 2MB limit
                    $error = 'Image must be smaller than 2MB.';
                } else {
                    // Delete old image if it exists
                    if ($user['profile_picture'] && file_exists('uploads/' . $user['profile_picture'])) {
                        unlink('uploads/' . $user['profile_picture']);
                    }

                    // Create a unique filename
                    $new_image_name = 'profile_' . uniqid() . '.' . $ext;
                    move_uploaded_file($_FILES['profile_picture']['tmp_name'], 'uploads/' . $new_image_name);
                }
            }

            if (!$error) {
                // Update user in database
                $stmt = $pdo->prepare(
                    "UPDATE users SET username = ?, email = ?, profile_picture = ? WHERE id = ?"
                );
                $stmt->execute([$username, $email, $new_image_name, $user_id]);

                // Update session info
                $_SESSION['username'] = $username;
                $_SESSION['profile_picture'] = $new_image_name;
                
                $success = 'Profile updated successfully!';
                
                // Refresh user data
                $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
                $stmt->execute([$user_id]);
                $user = $stmt->fetch();
            }
        }
    }
}
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow border-0 overflow-hidden">
            <div class="card-header bg-dark text-warning py-3 text-center">
                <h4 class="mb-0 fw-bold">Your Profile</h4>
            </div>
            <div class="card-body p-4">

                <?php if ($error): ?>
                    <div class="alert alert-danger border-0 shadow-sm"><?php echo $error; ?></div>
                <?php endif; ?>

                <?php if ($success): ?>
                    <div class="alert alert-success border-0 shadow-sm"><?php echo $success; ?></div>
                <?php endif; ?>

                <div class="text-center mb-4">
                    <?php if ($user['profile_picture']): ?>
                        <img src="uploads/<?php echo htmlspecialchars($user['profile_picture']); ?>" 
                             alt="Profile Picture" class="rounded-circle shadow-sm border" 
                             style="width: 150px; height: 150px; object-fit: cover;">
                    <?php else: ?>
                        <div class="bg-secondary text-white rounded-circle d-flex align-items-center justify-content-center mx-auto shadow-sm" 
                             style="width: 150px; height: 150px; font-size: 4rem;">
                            <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                        </div>
                    <?php endif; ?>
                </div>

                <form method="POST" action="profile.php" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="username" class="form-label fw-bold">Username</label>
                        <input type="text" class="form-control border-2" id="username" name="username" 
                               required value="<?php echo htmlspecialchars($user['username']); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label fw-bold">Email Address</label>
                        <input type="email" class="form-control border-2" id="email" name="email" 
                               required value="<?php echo htmlspecialchars($user['email']); ?>">
                    </div>

                    <div class="mb-4">
                        <label for="profile_picture" class="form-label fw-bold">Change Profile Picture</label>
                        <input type="file" class="form-control border-2" id="profile_picture" name="profile_picture" accept="image/*">
                        <small class="text-muted">Max size 2MB. Allowed: JPG, PNG, GIF, WEBP</small>
                    </div>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary btn-lg fw-bold">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
