<?php
// manage_films.php
// Add, Edit, and Delete films - full CRUD on one page

require_once 'DatabaseConnection.php';
require_once 'includes/header.php';

// Must be logged in and an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

$error   = '';
$success = '';
$edit_film = null; // holds film data when editing

// ---- HANDLE ACTIONS ----

// Handle ADD or EDIT form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title        = trim($_POST['title']);
    $genre        = trim($_POST['genre']);
    $release_year = (int)$_POST['release_year'];
    $description  = trim($_POST['description']);
    $film_id      = isset($_POST['film_id']) ? (int)$_POST['film_id'] : 0;

    if (empty($title)) {
        $error = 'Film title is required.';
    } else {
        if ($film_id > 0) {
            // UPDATE existing film
            $stmt = $pdo->prepare(
                "UPDATE films SET title = ?, genre = ?, release_year = ?, description = ?
                 WHERE id = ?"
            );
            $stmt->execute([$title, $genre, $release_year, $description, $film_id]);
            $success = 'Film updated successfully!';
        } else {
            // INSERT new film
            $stmt = $pdo->prepare(
                "INSERT INTO films (title, genre, release_year, description)
                 VALUES (?, ?, ?, ?)"
            );
            $stmt->execute([$title, $genre, $release_year, $description]);
            $success = 'Film added successfully!';
        }
    }
}

// Handle DELETE
if (isset($_GET['delete'])) {
    $film_id = (int)$_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM films WHERE id = ?");
    $stmt->execute([$film_id]);
    $success = 'Film deleted.';
}

// Handle EDIT - load the film into the form
if (isset($_GET['edit'])) {
    $film_id = (int)$_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM films WHERE id = ?");
    $stmt->execute([$film_id]);
    $edit_film = $stmt->fetch();
}

// Fetch all films to display in the table
$stmt  = $pdo->query("SELECT * FROM films ORDER BY title ASC");
$films = $stmt->fetchAll();
?>

<div class="row align-items-center mb-4">
    <div class="col">
        <h2 class="m-0">Manage Films</h2>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger border-0 shadow-sm"><?php echo $error; ?></div>
<?php endif; ?>

<?php if ($success): ?>
    <div class="alert alert-success border-0 shadow-sm"><?php echo $success; ?></div>
<?php endif; ?>

<div class="row mt-4">
    <!-- ADD / EDIT FORM -->
    <div class="col-lg-4 mb-4">
        <div class="card shadow border-0">
            <div class="card-header bg-dark text-warning py-3">
                <h5 class="mb-0 fw-bold"><?php echo $edit_film ? 'Edit Film' : 'Add New Film'; ?></h5>
            </div>
            <div class="card-body p-4">
                <form method="POST" action="manage_films.php">
                    <!-- Hidden film ID when editing -->
                    <?php if ($edit_film): ?>
                        <input type="hidden" name="film_id" value="<?php echo $edit_film['id']; ?>">
                    <?php endif; ?>

                    <div class="mb-3">
                        <label for="title" class="form-label fw-bold">Film Title <span class="text-danger">*</span></label>
                        <input type="text" class="form-control border-2" id="title" name="title" required
                               value="<?php echo $edit_film ? htmlspecialchars($edit_film['title']) : ''; ?>"
                               placeholder="e.g. Inception">
                    </div>

                    <div class="mb-3">
                        <label for="genre" class="form-label fw-bold">Genre</label>
                        <input type="text" class="form-control border-2" id="genre" name="genre"
                               value="<?php echo $edit_film ? htmlspecialchars($edit_film['genre']) : ''; ?>"
                               placeholder="e.g. Sci-Fi, Action">
                    </div>

                    <div class="mb-3">
                        <label for="release_year" class="form-label fw-bold">Release Year</label>
                        <input type="number" class="form-control border-2" id="release_year" name="release_year"
                               min="1888" max="<?php echo date('Y') + 5; ?>"
                               value="<?php echo $edit_film ? $edit_film['release_year'] : date('Y'); ?>">
                    </div>

                    <div class="mb-4">
                        <label for="description" class="form-label fw-bold">Brief Description</label>
                        <textarea class="form-control border-2" id="description" name="description"
                                  rows="3"><?php echo $edit_film ? htmlspecialchars($edit_film['description']) : ''; ?></textarea>
                    </div>

                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary"><?php echo $edit_film ? 'Update Film' : 'Add Film'; ?></button>
                        <?php if ($edit_film): ?>
                            <a href="manage_films.php" class="btn btn-outline-secondary">Cancel Edit</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- FILMS TABLE -->
    <div class="col-lg-8">
        <div class="card shadow border-0">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0 fw-bold">All Films (<?php echo count($films); ?>)</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">Title</th>
                                <th>Genre</th>
                                <th>Year</th>
                                <th class="text-end pe-4">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($films as $film): ?>
                            <tr>
                                <td class="ps-4">
                                    <span class="fw-bold"><?php echo htmlspecialchars($film['title']); ?></span>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark border"><?php echo htmlspecialchars($film['genre']); ?></span>
                                </td>
                                <td><?php echo $film['release_year']; ?></td>
                                <td class="text-end pe-4">
                                    <a href="manage_films.php?edit=<?php echo $film['id']; ?>"
                                       class="btn btn-sm btn-outline-warning">Edit</a>
                                    <a href="manage_films.php?delete=<?php echo $film['id']; ?>"
                                       class="btn btn-sm btn-outline-danger"
                                       onclick="return confirm('Delete this film? All related reviews will be lost.')">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($films)): ?>
                            <tr>
                                <td colspan="4" class="text-center py-4 text-muted">No films added yet.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
