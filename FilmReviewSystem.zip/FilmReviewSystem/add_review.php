<?php
// add_review.php
// Lets logged-in users add a new film review

require_once 'DatabaseConnection.php';
require_once 'includes/header.php';

// Only logged-in users can access this page
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$error   = '';
$success = '';

// Get all films for the dropdown list
$stmt  = $pdo->query("SELECT id, title FROM films ORDER BY title ASC");
$films = $stmt->fetchAll();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $film_id     = $_POST['film_id'];
    $user_id     = $_SESSION['user_id']; // Automatically set to logged-in user
    $rating      = (int)$_POST['rating'];
    $review_text = trim($_POST['review_text']);
    $image_name  = NULL;

    // Validation
    if (empty($film_id) || empty($review_text) || $rating < 1 || $rating > 10) {
        $error = 'Please fill in all required fields and choose a valid rating.';
    } else {
        // Handle optional image upload
        if (!empty($_FILES['image']['name'])) {
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            $ext     = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));

            if (!in_array($ext, $allowed)) {
                $error = 'Only JPG, PNG, GIF or WEBP images are allowed.';
            } elseif ($_FILES['image']['size'] > 2000000) { // 2MB limit
                $error = 'Image must be smaller than 2MB.';
            } else {
                // Create a unique filename so images don't overwrite each other
                $image_name = uniqid() . '.' . $ext;
                move_uploaded_file($_FILES['image']['tmp_name'], 'uploads/' . $image_name);
            }
        }

        if (!$error) {
            // Insert review into database
            $stmt = $pdo->prepare(
                "INSERT INTO reviews (film_id, user_id, review_text, rating, image)
                 VALUES (?, ?, ?, ?, ?)"
            );
            $stmt->execute([$film_id, $user_id, $review_text, $rating, $image_name]);

            $success = 'Review added successfully! <a href="index.php">View all reviews</a>';
        }
    }
}
?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow border-0 overflow-hidden">
            <div class="card-header bg-dark text-warning py-3">
                <h4 class="mb-0 fw-bold">Write a Film Review</h4>
            </div>
            <div class="card-body p-4">

                <?php if ($error): ?>
                    <div class="alert alert-danger border-0 shadow-sm"><?php echo $error; ?></div>
                <?php endif; ?>

                <?php if ($success): ?>
                    <div class="alert alert-success border-0 shadow-sm"><?php echo $success; ?></div>
                <?php endif; ?>

                <form method="POST" action="add_review.php" enctype="multipart/form-data">

                    <!-- Film dropdown (Requirement F) -->
                    <div class="mb-4">
                        <label for="film_id" class="form-label fw-bold">Which movie are you reviewing? <span class="text-danger">*</span></label>
                        <select class="form-select form-select-lg border-2" id="film_id" name="film_id" required>
                            <option value="">-- Select a film --</option>
                            <?php foreach ($films as $film): ?>
                                <option value="<?php echo $film['id']; ?>"
                                    <?php echo (isset($_POST['film_id']) && $_POST['film_id'] == $film['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($film['title']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (empty($films)): ?>
                            <div class="mt-2 p-2 bg-light rounded">
                                <small class="text-warning fw-bold">No films available. 
                                    <a href="manage_films.php" class="text-decoration-none">Add a film first.</a>
                                </small>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Star rating selector -->
                    <div class="mb-4">
                        <label for="rating" class="form-label fw-bold">Your Rating (1–10) <span class="text-danger">*</span></label>
                        <select class="form-select form-select-lg border-2" id="rating" name="rating" required>
                            <option value="">-- Choose a rating --</option>
                            <?php for ($i = 1; $i <= 10; $i++): ?>
                                <option value="<?php echo $i; ?>"
                                    <?php echo (isset($_POST['rating']) && $_POST['rating'] == $i) ? 'selected' : ''; ?>>
                                    <?php echo $i . '/10'; ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <!-- Review text -->
                    <div class="mb-4">
                        <label for="review_text" class="form-label fw-bold">Your Thoughts <span class="text-danger">*</span></label>
                        <textarea class="form-control border-2" id="review_text" name="review_text"
                                  rows="6" required
                                  placeholder="What did you think about the story, acting, and visuals?"><?php echo isset($_POST['review_text']) ? htmlspecialchars($_POST['review_text']) : ''; ?></textarea>
                    </div>

                    <!-- Optional image upload -->
                    <div class="mb-4">
                        <label for="image" class="form-label fw-bold">Add a Screenshot (optional)</label>
                        <div class="input-group">
                            <input type="file" class="form-control border-2" id="image" name="image"
                                   accept="image/*">
                        </div>
                        <div class="form-text">JPG, PNG, GIF or WEBP. Max 2MB.</div>
                    </div>

                    <div class="d-grid gap-2 d-md-flex justify-content-md-start mt-5">
                        <button type="submit" class="btn btn-primary btn-lg px-5">Post Review</button>
                        <a href="index.php" class="btn btn-outline-secondary btn-lg px-4">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
