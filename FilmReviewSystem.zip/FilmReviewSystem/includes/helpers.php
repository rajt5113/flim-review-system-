<?php
// includes/helpers.php
// Reusable helper functions

/**
 * Displays a star rating visually
 * Example: rating 8 = ★★★★★★★★☆☆
 *
 * @param int $rating  The rating value (1-10)
 * @return string      HTML string of filled and empty stars
 */
function displayStars($rating) {
    $stars = '';
    for ($i = 1; $i <= 10; $i++) {
        if ($i <= $rating) {
            $stars .= '<span class="star-rating">★</span>';  // filled star
        } else {
            $stars .= '<span class="star-empty">☆</span>';   // empty star
        }
    }
    $stars .= ' <small class="text-muted">(' . $rating . '/10)</small>';
    return $stars;
}
?>
