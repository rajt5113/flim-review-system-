<?php
// edit_review.php
// Lets a logged-in user edit one of their reviews

require_once 'DatabaseConnection.php';
require_once 'includes/header.php';

// Must be logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$error   = '';
$success = '';
$review_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch the review from the database
$stmt = $pdo->prepare("SELECT * FROM reviews WHERE id = ?");
$stmt->execute([$review_id]);
$review = $stmt->fetch();

// Check the review exists
if (!$review) {
    echo '<div class="alert alert-danger">Review not found.</div>';
    require_once 'includes/footer.php';
    exit;
}

// Get all films for the dropdown
$stmt  = $pdo->query("SELECT id, title FROM films ORDER BY title ASC");
$films = $stmt->fetchAll();

// Get all users for the dropdown (Requirement F)
$stmt  = $pdo->query("SELECT id, username FROM users ORDER BY username ASC");
$users = $stmt->fetchAll();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $film_id     = $_POST['film_id'];
    $user_id     = $_POST['user_id']; // selected reviewer (Requirement F)
    $rating      = (int)$_POST['rating'];
    $review_text = trim($_POST['review_text']);
    $image_name  = $review['image']; // keep existing image by default

    if (empty($film_id) || empty($user_id) || empty($review_text) || $rating < 1 || $rating > 10) {
        $error = 'Please fill in all required fields.';
    } else {
        // Handle new image upload (if provided)
        if (!empty($_FILES['image']['name'])) {
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            $ext     = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));

            if (!in_array($ext, $allowed)) {
                $error = 'Only JPG, PNG, GIF or WEBP images are allowed.';
            } elseif ($_FILES['image']['size'] > 2000000) {
                $error = 'Image must be smaller than 2MB.';
            } else {
                // Delete old image if there was one
                if ($review['image'] && file_exists('uploads/' . $review['image'])) {
                    unlink('uploads/' . $review['image']);
                }
                $image_name = uniqid() . '.' . $ext;
                move_uploaded_file($_FILES['image']['tmp_name'], 'uploads/' . $image_name);
            }
        }

        if (!$error) {
            // Update the review in the database
            $stmt = $pdo->prepare(
                "UPDATE reviews SET film_id = ?, user_id = ?, review_text = ?, rating = ?, image = ?
                 WHERE id = ?"
            );
            $stmt->execute([$film_id, $user_id, $review_text, $rating, $image_name, $review_id]);

            $success = 'Review updated! <a href="index.php">Back to reviews</a>';

            // Refresh the review data to show updated values
            $stmt = $pdo->prepare("SELECT * FROM reviews WHERE id = ?");
            $stmt->execute([$review_id]);
            $review = $stmt->fetch();
        }
    }
}
?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow border-0 overflow-hidden">
            <div class="card-header bg-dark text-warning py-3">
                <h4 class="mb-0 fw-bold">Edit Review</h4>
            </div>
            <div class="card-body p-4">

                <?php if ($error): ?>
                    <div class="alert alert-danger border-0 shadow-sm"><?php echo $error; ?></div>
                <?php endif; ?>

                <?php if ($success): ?>
                    <div class="alert alert-success border-0 shadow-sm"><?php echo $success; ?></div>
                <?php endif; ?>

                <form method="POST" action="edit_review.php?id=<?php echo $review_id; ?>"
                      enctype="multipart/form-data">

                    <!-- Film dropdown (Requirement F) -->
                    <div class="mb-4">
                        <label for="film_id" class="form-label fw-bold">Film <span class="text-danger">*</span></label>
                        <select class="form-select form-select-lg border-2" id="film_id" name="film_id" required>
                            <option value="">-- Select a film --</option>
                            <?php foreach ($films as $film): ?>
                                <option value="<?php echo $film['id']; ?>"
                                    <?php echo ($review['film_id'] == $film['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($film['title']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Reviewer dropdown (Requirement F) -->
                    <div class="mb-4">
                        <label for="user_id" class="form-label fw-bold">Reviewer <span class="text-danger">*</span></label>
                        <select class="form-select form-select-lg border-2" id="user_id" name="user_id" required>
                            <option value="">-- Select a reviewer --</option>
                            <?php foreach ($users as $u): ?>
                                <option value="<?php echo $u['id']; ?>"
                                    <?php echo ($review['user_id'] == $u['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($u['username']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Rating selector -->
                    <div class="mb-4">
                        <label for="rating" class="form-label fw-bold">Rating (1–10) <span class="text-danger">*</span></label>
                        <select class="form-select form-select-lg border-2" id="rating" name="rating" required>
                            <?php for ($i = 1; $i <= 10; $i++): ?>
                                <option value="<?php echo $i; ?>"
                                    <?php echo ($review['rating'] == $i) ? 'selected' : ''; ?>>
                                    <?php echo $i . '/10'; ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <!-- Review text -->
                    <div class="mb-4">
                        <label for="review_text" class="form-label fw-bold">Your Review <span class="text-danger">*</span></label>
                        <textarea class="form-control border-2" id="review_text" name="review_text"
                                  rows="6" required><?php echo htmlspecialchars($review['review_text']); ?></textarea>
                    </div>

                    <!-- Image upload -->
                    <div class="mb-4">
                        <label for="image" class="form-label fw-bold">Change Screenshot (optional)</label>
                        <?php if ($review['image']): ?>
                            <div class="mb-2">
                                <small class="text-muted">Current image:</small><br>
                                <img src="uploads/<?php echo $review['image']; ?>" width="100" class="rounded mt-1 border">
                            </div>
                        <?php endif; ?>
                        <input type="file" class="form-control border-2" id="image" name="image" accept="image/*">
                    </div>

                    <div class="d-grid gap-2 d-md-flex justify-content-md-start mt-5">
                        <button type="submit" class="btn btn-primary btn-lg px-5">Save Changes</button>
                        <a href="index.php" class="btn btn-outline-secondary btn-lg px-4">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
