<?php
// view_review.php
// Shows the full details of a single review

require_once 'DatabaseConnection.php';
require_once 'includes/header.php';
require_once 'includes/helpers.php';

$review_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch the review with film and user info
$stmt = $pdo->prepare(
    "SELECT reviews.id, reviews.review_text, reviews.rating, reviews.image, reviews.created_at,
            films.title AS film_title, films.genre, films.release_year, films.description AS film_description,
            users.username AS reviewer_name, users.id AS reviewer_id, users.profile_picture AS reviewer_pic
     FROM reviews
     JOIN films ON reviews.film_id = films.id
     JOIN users ON reviews.user_id = users.id
     WHERE reviews.id = ?"
);
$stmt->execute([$review_id]);
$review = $stmt->fetch();

if (!$review) {
    echo '<div class="alert alert-danger">Review not found. <a href="index.php">Go back home</a></div>';
    require_once 'includes/footer.php';
    exit;
}
?>

<div class="row justify-content-center">
    <div class="col-md-8">

        <!-- Back button -->
        <a href="index.php" class="btn btn-outline-dark btn-sm mb-4">Back to all reviews</a>

        <div class="card shadow border-0 overflow-hidden">
            <!-- Film screenshot if available -->
            <?php if (!empty($review['image'])): ?>
                <img src="uploads/<?php echo htmlspecialchars($review['image']); ?>"
                     class="card-img-top" alt="Film screenshot"
                     style="max-height: 450px; object-fit: cover;">
            <?php endif; ?>

            <div class="card-body p-4">
                <!-- Film title and year -->
                <h2 class="card-title fw-bold mb-1">
                    <?php echo htmlspecialchars($review['film_title']); ?>
                </h2>
                <p class="text-muted fs-5 mb-3">(<?php echo htmlspecialchars($review['release_year']); ?>)</p>

                <!-- Genre -->
                <?php if (!empty($review['genre'])): ?>
                    <span class="badge bg-light text-dark border mb-4"><?php echo htmlspecialchars($review['genre']); ?></span>
                <?php endif; ?>

                <!-- Film description -->
                <?php if (!empty($review['film_description'])): ?>
                    <div class="bg-light p-3 rounded mb-4">
                        <h6 class="fw-bold small text-uppercase text-muted mb-2">About the Movie</h6>
                        <p class="mb-0"><?php echo htmlspecialchars($review['film_description']); ?></p>
                    </div>
                <?php endif; ?>

                <hr class="my-4">

                <!-- Star rating - big display -->
                <div class="mb-4">
                    <h6 class="fw-bold small text-uppercase text-muted mb-2">Rating</h6>
                    <div class="fs-4">
                        <?php echo displayStars($review['rating']); ?>
                        <span class="ms-2 text-dark fw-bold"><?php echo $review['rating']; ?>/10</span>
                    </div>
                </div>

                <!-- Review text -->
                <h6 class="fw-bold small text-uppercase text-muted mb-2">Review</h6>
                <p class="card-text lead lh-base">
                    <?php echo nl2br(htmlspecialchars($review['review_text'])); ?>
                </p>
            </div>

            <div class="card-footer bg-light p-4 border-0 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center">
                    <?php if (!empty($review['reviewer_pic'])): ?>
                        <img src="uploads/<?php echo htmlspecialchars($review['reviewer_pic']); ?>" 
                             alt="User" class="rounded-circle me-3" 
                             style="width: 48px; height: 48px; object-fit: cover;">
                    <?php else: ?>
                        <div class="bg-secondary text-white rounded-circle me-3 d-flex align-items-center justify-content-center" 
                             style="width: 48px; height: 48px; font-size: 1.2rem;">
                            <?php echo strtoupper(substr($review['reviewer_name'], 0, 1)); ?>
                        </div>
                    <?php endif; ?>
                    <div class="small">
                        <span class="text-muted">Reviewed by:</span> 
                        <span class="fw-bold"><?php echo htmlspecialchars($review['reviewer_name']); ?></span>
                        <br>
                        <span class="text-muted">Date:</span> 
                        <span><?php echo date('d F Y', strtotime($review['created_at'])); ?></span>
                    </div>
                </div>

                <!-- Edit/Delete for logged-in users -->
                <?php if (isset($_SESSION['user_id'])): ?>
                    <div class="d-flex gap-2">
                        <a href="edit_review.php?id=<?php echo $review['id']; ?>"
                           class="btn btn-sm btn-outline-warning">Edit</a>
                        <a href="delete_review.php?id=<?php echo $review['id']; ?>"
                           class="btn btn-sm btn-outline-danger"
                           onclick="return confirm('Delete this review?')">Delete</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
