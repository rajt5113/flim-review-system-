<?php
require_once 'DatabaseConnection.php';

try {
    // Add role column to users table
    $pdo->exec("ALTER TABLE users ADD COLUMN role ENUM('admin', 'user') DEFAULT 'user' AFTER email");
    echo "Added 'role' column to 'users' table.\n";

    // Set the existing 'admin' user as an admin
    $stmt = $pdo->prepare("UPDATE users SET role = 'admin' WHERE username = 'admin'");
    $stmt->execute();
    echo "Updated 'admin' user role to 'admin'.\n";

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
