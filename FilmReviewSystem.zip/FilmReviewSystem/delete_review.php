<?php
// delete_review.php
// Deletes a review from the database

require_once 'DatabaseConnection.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Must be logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$review_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch the review - also get the image filename so we can delete it
$stmt = $pdo->prepare("SELECT * FROM reviews WHERE id = ?");
$stmt->execute([$review_id]);
$review = $stmt->fetch();

if ($review) {
    // Delete the image file from the uploads folder if it exists
    if (!empty($review['image']) && file_exists('uploads/' . $review['image'])) {
        unlink('uploads/' . $review['image']);
    }

    // Delete the review from the database
    $stmt = $pdo->prepare("DELETE FROM reviews WHERE id = ?");
    $stmt->execute([$review_id]);
}

// Go back to home page after deletion
header('Location: index.php');
exit;
?>
