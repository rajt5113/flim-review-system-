<?php
// manage_users.php
// View, Add, Edit and Delete users

require_once 'DatabaseConnection.php';
require_once 'includes/header.php';

// Must be logged in and an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

$error     = '';
$success   = '';
$edit_user = null;

// ---- HANDLE ACTIONS ----

// Handle ADD or EDIT form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email    = trim($_POST['email']);
    $password = $_POST['password'];
    $user_id  = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;

    if (empty($username) || empty($email)) {
        $error = 'Username and email are required.';
    } else {
        if ($user_id > 0) {
            // UPDATE existing user
            if (!empty($password)) {
                // Change password if a new one was entered
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare(
                    "UPDATE users SET username = ?, email = ?, password = ? WHERE id = ?"
                );
                $stmt->execute([$username, $email, $hashed, $user_id]);
            } else {
                // Keep existing password
                $stmt = $pdo->prepare(
                    "UPDATE users SET username = ?, email = ? WHERE id = ?"
                );
                $stmt->execute([$username, $email, $user_id]);
            }
            $success = 'User updated!';
        } else {
            // ADD new user - password is required
            if (empty($password)) {
                $error = 'Password is required for new users.';
            } else {
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare(
                    "INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, 'user')"
                );
                $stmt->execute([$username, $email, $hashed]);
                $success = 'User added!';
            }
        }
    }
}

// Handle DELETE
if (isset($_GET['delete'])) {
    $user_id = (int)$_GET['delete'];
    // Prevent deleting yourself
    if ($user_id == $_SESSION['user_id']) {
        $error = 'You cannot delete your own account while logged in.';
    } else {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $success = 'User deleted.';
    }
}

// Handle EDIT - load user into form
if (isset($_GET['edit'])) {
    $user_id = (int)$_GET['edit'];
    $stmt = $pdo->prepare("SELECT id, username, email FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $edit_user = $stmt->fetch();
}

// Get all users
$stmt  = $pdo->query("SELECT id, username, email, created_at FROM users ORDER BY username ASC");
$users = $stmt->fetchAll();
?>

<div class="row align-items-center mb-4">
    <div class="col">
        <h2 class="m-0">Manage Users</h2>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger border-0 shadow-sm"><?php echo $error; ?></div>
<?php endif; ?>

<?php if ($success): ?>
    <div class="alert alert-success border-0 shadow-sm"><?php echo $success; ?></div>
<?php endif; ?>

<div class="row mt-4">
    <!-- ADD / EDIT FORM -->
    <div class="col-lg-4 mb-4">
        <div class="card shadow border-0">
            <div class="card-header bg-dark text-warning py-3">
                <h5 class="mb-0 fw-bold"><?php echo $edit_user ? 'Edit User' : 'Add User'; ?></h5>
            </div>
            <div class="card-body p-4">
                <form method="POST" action="manage_users.php">
                    <?php if ($edit_user): ?>
                        <input type="hidden" name="user_id" value="<?php echo $edit_user['id']; ?>">
                    <?php endif; ?>

                    <div class="mb-3">
                        <label for="username" class="form-label fw-bold">Username <span class="text-danger">*</span></label>
                        <input type="text" class="form-control border-2" id="username" name="username" required
                               value="<?php echo $edit_user ? htmlspecialchars($edit_user['username']) : ''; ?>"
                               placeholder="e.g. movie_fan_123">
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label fw-bold">Email <span class="text-danger">*</span></label>
                        <input type="email" class="form-control border-2" id="email" name="email" required
                               value="<?php echo $edit_user ? htmlspecialchars($edit_user['email']) : ''; ?>"
                               placeholder="e.g. user@example.com">
                    </div>

                    <div class="mb-4">
                        <label for="password" class="form-label fw-bold">
                            Password
                            <?php echo $edit_user ? '<small class="text-muted fw-normal">(leave blank to keep current)</small>' : '<span class="text-danger">*</span>'; ?>
                        </label>
                        <input type="password" class="form-control border-2" id="password" name="password"
                               <?php echo !$edit_user ? 'required' : ''; ?> minlength="6">
                    </div>

                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary"><?php echo $edit_user ? 'Update User' : 'Add User'; ?></button>
                        <?php if ($edit_user): ?>
                            <a href="manage_users.php" class="btn btn-outline-secondary">Cancel Edit</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- USERS TABLE -->
    <div class="col-lg-8">
        <div class="card shadow border-0">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0 fw-bold">All Users (<?php echo count($users); ?>)</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">Username</th>
                                <th>Email</th>
                                <th>Joined</th>
                                <th class="text-end pe-4">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                            <tr <?php echo $user['id'] == $_SESSION['user_id'] ? 'class="table-warning"' : ''; ?>>
                                <td class="ps-4">
                                    <div class="d-flex align-items-center">
                                        <div class="bg-warning text-dark rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 32px; height: 32px; font-weight: bold;">
                                            <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                                        </div>
                                        <span class="fw-bold"><?php echo htmlspecialchars($user['username']); ?></span>
                                        <?php if ($user['id'] == $_SESSION['user_id']): ?>
                                            <span class="badge bg-warning text-dark ms-2">You</span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td><?php echo date('M Y', strtotime($user['created_at'])); ?></td>
                                <td class="text-end pe-4">
                                    <a href="manage_users.php?edit=<?php echo $user['id']; ?>"
                                       class="btn btn-sm btn-outline-warning">Edit</a>
                                    <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                        <a href="manage_users.php?delete=<?php echo $user['id']; ?>"
                                           class="btn btn-sm btn-outline-danger"
                                           onclick="return confirm('Delete this user?')">Delete</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
