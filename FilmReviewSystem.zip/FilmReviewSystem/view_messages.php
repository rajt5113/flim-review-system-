<?php
// view_messages.php
// Admin page to view contact form submissions

require_once 'DatabaseConnection.php';
require_once 'includes/header.php';

// Must be logged in and an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

$success = '';
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM contact_messages WHERE id = ?");
    $stmt->execute([$id]);
    $success = "Message deleted.";
}

// Fetch all messages
$stmt = $pdo->query("SELECT * FROM contact_messages ORDER BY sent_at DESC");
$messages = $stmt->fetchAll();
?>

<div class="row align-items-center mb-4">
    <div class="col">
        <h2 class="m-0">Contact Messages</h2>
    </div>
</div>

<?php if ($success): ?>
    <div class="alert alert-success border-0 shadow-sm"><?php echo $success; ?></div>
<?php endif; ?>

<div class="card shadow border-0">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-dark text-warning">
                    <tr>
                        <th class="ps-4">Date</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Message</th>
                        <th class="text-center pe-4">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($messages)): ?>
                        <tr>
                            <td colspan="5" class="text-center py-5 text-muted">
                                <p class="mb-0">No messages found.</p>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($messages as $msg): ?>
                            <tr>
                                <td class="ps-4 small text-muted">
                                    <?php echo date('M d, Y', strtotime($msg['sent_at'])); ?><br>
                                    <?php echo date('H:i', strtotime($msg['sent_at'])); ?>
                                </td>
                                <td class="fw-bold"><?php echo htmlspecialchars($msg['name']); ?></td>
                                <td><a href="mailto:<?php echo htmlspecialchars($msg['email']); ?>" class="text-decoration-none"><?php echo htmlspecialchars($msg['email']); ?></a></td>
                                <td>
                                    <div class="text-truncate" style="max-width: 300px;" title="<?php echo htmlspecialchars($msg['message']); ?>">
                                        <?php echo htmlspecialchars($msg['message']); ?>
                                    </div>
                                </td>
                                <td class="text-center pe-4">
                                    <button class="btn btn-sm btn-outline-primary me-1" data-bs-toggle="modal" data-bs-target="#msgModal<?php echo $msg['id']; ?>">View</button>
                                    <a href="view_messages.php?delete=<?php echo $msg['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this message?')">Delete</a>
                                </td>
                            </tr>

                            <!-- Modal for full message -->
                            <div class="modal fade" id="msgModal<?php echo $msg['id']; ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header bg-dark text-warning">
                                            <h5 class="modal-title">Message from <?php echo htmlspecialchars($msg['name']); ?></h5>
                                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <p><strong>From:</strong> <?php echo htmlspecialchars($msg['name']); ?> (<?php echo htmlspecialchars($msg['email']); ?>)</p>
                                            <p><strong>Sent:</strong> <?php echo date('F j, Y, g:i a', strtotime($msg['sent_at'])); ?></p>
                                            <hr>
                                            <p class="mb-0" style="white-space: pre-wrap;"><?php echo htmlspecialchars($msg['message']); ?></p>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            <a href="mailto:<?php echo htmlspecialchars($msg['email']); ?>" class="btn btn-primary">Reply</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
