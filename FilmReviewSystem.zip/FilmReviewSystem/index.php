<?php
// index.php
// Home page - shows all film reviews

require_once 'includes/header.php';
require_once 'includes/helpers.php';
require_once 'DatabaseConnection.php';

// Fetch all reviews, joined with film and user info
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$genre_filter = isset($_GET['genre']) ? trim($_GET['genre']) : '';

$sql = "SELECT reviews.id, reviews.review_text, reviews.rating, reviews.image, reviews.created_at,
               films.title AS film_title, films.genre, films.release_year,
               users.username AS reviewer_name, users.profile_picture AS reviewer_pic
        FROM reviews
        JOIN films ON reviews.film_id = films.id
        JOIN users ON reviews.user_id = users.id";

$params = [];
$where_clauses = [];

if ($search !== '') {
    $where_clauses[] = "(films.title LIKE ? OR reviews.review_text LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($genre_filter !== '') {
    $where_clauses[] = "films.genre = ?";
    $params[] = $genre_filter;
}

if (!empty($where_clauses)) {
    $sql .= " WHERE " . implode(" AND ", $where_clauses);
}

$sql .= " ORDER BY reviews.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$reviews = $stmt->fetchAll();

// Get unique genres for the filter dropdown
$genres_stmt = $pdo->query("SELECT DISTINCT genre FROM films WHERE genre IS NOT NULL AND genre != '' ORDER BY genre ASC");
$all_genres = $genres_stmt->fetchAll(PDO::FETCH_COLUMN);
?>

<!-- Hero Section -->
<div class="p-5 mb-5 text-white rounded-3 shadow hero-section" style="background: linear-gradient(rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.8)), url('https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80'); background-size: cover; background-position: center;">
    <div class="container-fluid py-5 text-center">
        <h1 class="display-4 fw-bold" style="color: var(--primary-color);">Discover Your Next Favorite Film</h1>
        <p class="fs-4">Honest reviews from movie enthusiasts like you.</p>
        <?php if (isset($_SESSION['user_id'])): ?>
            <a href="add_review.php" class="btn btn-lg px-4 mt-3 shadow-sm" style="background-color: var(--primary-color); color: white; border: none; font-weight: 700;">Share Your Review</a>
        <?php else: ?>
            <a href="register.php" class="btn btn-lg px-4 mt-3 shadow-sm" style="background-color: var(--primary-color); color: white; border: none; font-weight: 700;">Join the Community</a>
        <?php endif; ?>
    </div>
</div>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
    <h2 class="m-0">Latest Film Reviews</h2>
    <div class="d-flex flex-grow-1 justify-content-md-end gap-2">
        <form method="GET" action="index.php" class="d-flex gap-2 flex-grow-1 flex-md-grow-0">
            <select name="genre" class="form-select form-select-sm" style="width: auto;" onchange="this.form.submit()">
                <option value="">All Genres</option>
                <?php foreach ($all_genres as $g): ?>
                    <option value="<?php echo htmlspecialchars($g); ?>" <?php echo $genre_filter === $g ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($g); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <input type="text" name="search" class="form-control form-control-sm" placeholder="Search movies or reviews..." value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit" class="btn btn-sm btn-dark">Search</button>
            <?php if ($search !== '' || $genre_filter !== ''): ?>
                <a href="index.php" class="btn btn-sm btn-outline-secondary">Clear</a>
            <?php endif; ?>
        </form>
        <?php if (isset($_SESSION['user_id'])): ?>
            <a href="add_review.php" class="btn btn-primary btn-sm d-none d-md-inline-block">Add Review</a>
        <?php endif; ?>
    </div>
</div>

<?php if (empty($reviews)): ?>
    <div class="alert alert-info py-4 text-center">
        <?php if ($search !== '' || $genre_filter !== ''): ?>
            <p class="mb-2">No reviews found matching your criteria.</p>
            <a href="index.php" class="btn btn-sm btn-outline-info">View All Reviews</a>
        <?php else: ?>
            <p class="mb-2">No reviews yet.</p>
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="add_review.php" class="btn btn-sm btn-info">Be the first to add one!</a>
            <?php else: ?>
                <a href="login.php" class="btn btn-sm btn-info">Login to add a review!</a>
            <?php endif; ?>
        <?php endif; ?>
    </div>
<?php else: ?>
    <div class="row">
        <?php foreach ($reviews as $review): ?>
        <div class="col-md-6 mb-4">
            <div class="card review-card shadow-sm h-100">
                <!-- Optional film screenshot -->
                <?php if (!empty($review['image'])): ?>
                    <img src="uploads/<?php echo htmlspecialchars($review['image']); ?>"
                         class="card-img-top" alt="Film screenshot"
                         style="max-height: 200px; object-fit: cover;">
                <?php endif; ?>

                <div class="card-body">
                    <!-- Film title -->
                    <h5 class="card-title">
                        <?php echo htmlspecialchars($review['film_title']); ?>
                        <small class="text-muted">(<?php echo htmlspecialchars($review['release_year']); ?>)</small>
                    </h5>

                    <!-- Genre badge -->
                    <?php if (!empty($review['genre'])): ?>
                        <span class="badge bg-secondary mb-2"><?php echo htmlspecialchars($review['genre']); ?></span>
                    <?php endif; ?>

                    <!-- Star rating -->
                    <div class="mb-2">
                        <?php echo displayStars($review['rating']); ?>
                    </div>

                    <!-- Review text - truncated on homepage -->
                    <p class="card-text"><?php echo nl2br(htmlspecialchars(substr($review['review_text'], 0, 200))); ?>
                        <?php if (strlen($review['review_text']) > 200): ?>
                            <a href="view_review.php?id=<?php echo $review['id']; ?>">... read more</a>
                        <?php endif; ?>
                    </p>
                </div>

                <div class="card-footer text-muted d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center">
                        <?php if (!empty($review['reviewer_pic'])): ?>
                            <img src="uploads/<?php echo htmlspecialchars($review['reviewer_pic']); ?>" 
                                 alt="User" class="rounded-circle me-2" 
                                 style="width: 24px; height: 24px; object-fit: cover;">
                        <?php else: ?>
                            <div class="bg-secondary text-white rounded-circle me-2 d-flex align-items-center justify-content-center" 
                                 style="width: 24px; height: 24px; font-size: 0.7rem;">
                                <?php echo strtoupper(substr($review['reviewer_name'], 0, 1)); ?>
                            </div>
                        <?php endif; ?>
                        <small>User: <?php echo htmlspecialchars($review['reviewer_name']); ?></small>
                    </div>
                    <small>Date: <?php echo date('d M Y', strtotime($review['created_at'])); ?></small>

                    <!-- Edit/Delete buttons - only visible to the review owner -->
                    <?php if (isset($_SESSION['user_id'])): ?>
                    <div>
                        <a href="edit_review.php?id=<?php echo $review['id']; ?>"
                           class="btn btn-sm btn-outline-warning">Edit</a>
                        <a href="delete_review.php?id=<?php echo $review['id']; ?>"
                           class="btn btn-sm btn-outline-danger"
                           onclick="return confirm('Delete this review?')">Delete</a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
