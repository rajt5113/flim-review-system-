<?php
// login.php
// Allows users to log in

require_once 'DatabaseConnection.php';
require_once 'includes/header.php';

$error = '';

// If already logged in, go to home
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    if (empty($username) || empty($password)) {
        $error = 'Please enter your username and password.';
    } else {
        // Look up the user in the database
        $stmt = $pdo->prepare("SELECT id, username, role, profile_picture, password FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        // Check the password matches the hash stored in the database
        if ($user && password_verify($password, $user['password'])) {
            // Save user info in session
            $_SESSION['user_id']  = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role']     = $user['role'];
            $_SESSION['profile_picture'] = $user['profile_picture'];

            // Redirect to home page after login
            header('Location: index.php');
            exit;
        } else {
            $error = 'Incorrect username or password.';
        }
    }
}
?>

<div class="row justify-content-center">
    <div class="col-md-5">
        <div class="card shadow border-0">
            <div class="card-header bg-dark text-warning py-3">
                <h4 class="mb-0 fw-bold">Login</h4>
            </div>
            <div class="card-body p-4">

                <?php if ($error): ?>
                    <div class="alert alert-danger border-0 shadow-sm"><?php echo $error; ?></div>
                <?php endif; ?>

                <form method="POST" action="login.php">
                    <div class="mb-3">
                        <label for="username" class="form-label fw-bold">Username</label>
                        <input type="text" class="form-control border-2" id="username"
                               name="username" required placeholder="Enter your username">
                    </div>

                    <div class="mb-4">
                        <label for="password" class="form-label fw-bold">Password</label>
                        <input type="password" class="form-control border-2" id="password"
                               name="password" required placeholder="Enter your password">
                    </div>

                    <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">Login</button>
                </form>

                <p class="mt-4 text-center small text-muted">
                    Don't have an account? <a href="register.php" class="text-decoration-none fw-bold" style="color: var(--primary-color);">Register here</a>
                </p>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
