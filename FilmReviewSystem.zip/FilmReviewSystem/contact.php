<?php
// contact.php
// Contact form - saves messages to database and optionally emails the admin

require_once 'DatabaseConnection.php';
require_once 'includes/header.php';

$error   = '';
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['name']);
    $email   = trim($_POST['email']);
    $message = trim($_POST['message']);

    if (empty($name) || empty($email) || empty($message)) {
        $error = 'Please fill in all fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        // Save the message to the database
        $stmt = $pdo->prepare(
            "INSERT INTO contact_messages (name, email, message) VALUES (?, ?, ?)"
        );
        $stmt->execute([$name, $email, $message]);

        // Send an email to the admin (Requirement G)
        $to      = 'rajt5113@gmail.com';
        $subject = 'New Contact Message from ' . $name;
        $body    = "Name: $name\nEmail: $email\n\nMessage:\n$message";
        
        // Better headers for email delivery
        $headers = "From: webmaster@filmreviewsystem.com" . "\r\n" .
                   "Reply-To: $email" . "\r\n" .
                   "X-Mailer: PHP/" . phpversion();
        
        // Attempt to send the email
        $mailSent = @mail($to, $subject, $body, $headers);

        if ($mailSent) {
            $success = 'Your message has been sent! We will get back to you soon.';
        } else {
            // Message is still saved in DB, so we can tell the user it's received
            // but internally we know the email failed.
            $success = 'Your message has been received! (Note: Email notification is pending server configuration).';
        }
    }
}
?>

<div class="row justify-content-center">
    <div class="col-md-7">
        <div class="card shadow border-0 overflow-hidden">
            <div class="card-header bg-dark text-warning py-3">
                <h4 class="mb-0 fw-bold">Contact Admin</h4>
            </div>
            <div class="card-body p-4">
                <p class="text-muted mb-4">Have a question or issue? Send us a message below.</p>

                <?php if ($error): ?>
                    <div class="alert alert-danger border-0 shadow-sm"><?php echo $error; ?></div>
                <?php endif; ?>

                <?php if ($success): ?>
                    <div class="alert alert-success border-0 shadow-sm"><?php echo $success; ?></div>
                <?php else: ?>

                <form method="POST" action="contact.php">
                    <div class="mb-3">
                        <label for="name" class="form-label fw-bold">Your Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control border-2" id="name" name="name" required
                               value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>"
                               placeholder="Enter your name">
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label fw-bold">Your Email <span class="text-danger">*</span></label>
                        <input type="email" class="form-control border-2" id="email" name="email" required
                               value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>"
                               placeholder="Enter your email">
                    </div>

                    <div class="mb-4">
                        <label for="message" class="form-label fw-bold">Message <span class="text-danger">*</span></label>
                        <textarea class="form-control border-2" id="message" name="message"
                                  rows="6" required
                                  placeholder="Write your message here..."><?php echo isset($_POST['message']) ? htmlspecialchars($_POST['message']) : ''; ?></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary btn-lg px-5">Send Message</button>
                </form>

                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
